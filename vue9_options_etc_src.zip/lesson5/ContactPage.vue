<!-- ContactPage.vue -->
<script>
export default {
  name: 'ContactPage',
}
</script>

<template>
  <div class="contact-page">
    <h2>연락처</h2>
    <p>이메일: example@example.com</p>
    <p>전화: 123-456-7890</p>
  </div>
</template>
