<!-- AboutPage.vue -->
<script>
export default {
  name: 'AboutPage',
}
</script>

<template>
  <div class="about-page">
    <h2>소개</h2>
    <p>
      Vue 3 동적 컴포넌트를 사용하여 탭 인터페이스를 구현하는 방법을 설명합니다.
    </p>
  </div>
</template>
